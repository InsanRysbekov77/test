
import './App.css';
import DataFetching from './components/DataFetch';

function App() {
  return (
    <div className="App">
      <DataFetching />
    </div>
  );
}

export default App;
